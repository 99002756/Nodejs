class employye{
    constructor(id,name,address)
    {
        this.id=id;
        this.name=name;
        this.address=address;

    }
    display(){
        const data=`The Name: ${this.name} The Address:${this.address} The Id:${this.id}`;
        console.log(data);
    }
}
const obj=new employye(1,"abir","Mumbai");
obj.display();

