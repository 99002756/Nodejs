var flipcart=require("./market")();
flipcart.addRecord({"id":1, "name":"Nokia","price":5000});
const data=flipcart.getAll();
for (const iterator of data)
{
    console.log(iterator);
}
