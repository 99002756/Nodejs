const events=require('events').EventEmitter;
let button=new events();
button.on("click",()=>{
    console.log("The obj was clicked");
})
button.on("dblClick",(arg)=>{
    console.log("The Event is handeled on"+arg);
})
button.emit("click");
button.emit("dblClick","button1");