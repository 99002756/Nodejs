/*const data = {"aaa":1,"bbb":2,"ccc":3};
console.log(data);
*/
/*const json = JSON.stringify(data);//object to json format
console.log(json);

let jsonObj = {"name":'aaa',"id":"123","place":"chennai"}
let info = JSON.parse(jsonObj);
console.log(info.name);
*/
///////File stream

const fs = require('fs');
class employee{
    constructor(id,name,address){
        this.id=id;
        this.name=name;
        this.address=address;
    }
}

let employees =[];
employees.push(new employee(99002763,"rmv","chennai"));
employees.push(new employee(99002764,"aac","blore"));
employees.push(new employee(99002765,"bbb","mysore"));

let jsonData = JSON.stringify(employees);
console.log(jsonData);
//let info = JSON.parse(jsonData);
//console.log(info);

function saveData(jsonData){
    const filename ="data.json";
    fs.writeFileSync(filename,jsonData, 'utf-8');
    console.log("Data is saved");
}
/*function loadData(){
    const filename = "data.json";
    const data = fs.readFileSync(filename,'utf-8');
    employees = JSON.parse(data);
}*/
saveData(jsonData);

/*loadData();

for (const emp of employees){
    console.log(emp.name);
}*/