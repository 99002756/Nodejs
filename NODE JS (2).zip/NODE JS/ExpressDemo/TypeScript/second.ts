let elements:number[]=[];
elements.push(1);
elements.push(2);
elements.push(3);
elements.push(4);
for(const e of elements){
    console.log(e)
}
let fruits=Array <string> ();
fruits=["apple","mango","orange","banana"];
for(const fruit of fruits)
{
    console.log(fruit);
}
let fruitsAndPrices:(string|number)[]=["apple",340,"mangoes",100,"banana",200]
for(const e of fruitsAndPrices){
    console.log(e);
}
//tuples
const emp:[number,string]=[1,"abir"];
const custBill:[string,number]=["dev",789];
let obj:any="Abir";
console.log(typeof(obj))