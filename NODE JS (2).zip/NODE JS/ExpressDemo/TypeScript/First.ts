function addNumbers(num1:number, num2:number):number{
    return num1+num2;
}
var sum=addNumbers(12,23);
console.log(sum);

var age:number=23;
var uname: string="Abir";
var currentstatus:boolean=true;
var data=`Name is ${uname} aged ${age}`;
console.log(data);