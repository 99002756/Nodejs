var elements = [];
elements.push(1);
elements.push(2);
elements.push(3);
elements.push(4);
for (var _i = 0, elements_1 = elements; _i < elements_1.length; _i++) {
    var e = elements_1[_i];
    console.log(e);
}
