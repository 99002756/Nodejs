abstract class Account{
    accno:number;
    accholder:string;
    accbalance:number;
    constructor(no:number,name:string,balance:number){
        this.accno=no;
        this.accholder=name;
        this.accbalance=balance
    }
    credit(amount:number)
    {
        this.accbalance+=amount
    }
    debit(amount:number){
        if(amount>this.accbalance)
        throw "Insufficient funds";
        this.accbalance-=amount
    }
    abstract calcInterest();
}
class SBAccount extends Account{
    calcInterest(){
        let r:number=6.5/100;
        let t:number=1/4;
        let p:number=this.accbalance;
        let interest:number=p*t*r;
        super.credit(interest);
    }
}
let acc:Account=new SBAccount(1,"Abir",90000);
acc.credit(20000);
acc.calcInterest();
console.log (acc.accbalance);
