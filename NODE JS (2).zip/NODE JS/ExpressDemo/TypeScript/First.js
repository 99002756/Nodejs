function addNumbers(num1, num2) {
    return num1 + num2;
}
var sum = addNumbers(12, 23);
console.log(sum);
var age = 23;
var uname = "Abir";
var currentstatus = true;
var data = "Name is " + uname + " aged " + age;
console.log(data);
