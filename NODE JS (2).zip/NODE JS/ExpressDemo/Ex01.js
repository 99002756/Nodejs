const express = require("express");
const parser=require("body-parser")
const app=express();
app.use(parser.urlencoded({extended:false}));
const root=__dirname;
app.get("/",(req,res)=>res.send("Testing"));
app.get("/Home",(req,res)=>res.send("<h1>Home page"));
app.get("/Newuser",(req,res)=>res.sendFile(root+"/UserRegisteration.html"));

app.get("/Register",(req,res)=>{
    const name=req.query.uname;
    const address=req.query.uaddress;
    const phone=req.query.uphone;
    res.send(`<h1>${name} from ${address} has been registered with us</h1><hr/>contact no is ${phone}`);
});
app.post("/Register",(req,res)=>{
    if(req.body==null){
        res.send("<h1>There is no data in the browser</h1>");
    }
    else{
    const name=req.query.uname;
    const address=req.query.uaddress;
    const phone=req.query.uphone;
    res.send(`<h1>${name} from ${address} has been registered with us</h1><hr/>contact no is ${phone}. This data is secured`);
    }
});
app.get("/",(req,res)=>res.send("Testing Express"))

app.listen(1234,()=>{
    console.log("server is running");
})