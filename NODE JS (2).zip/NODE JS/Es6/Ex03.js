const fs=require('fs');
/*const data=fs.readFileSync("market.js","utf-8");
console.log(data);

fs.readFile("Ex03.js",'utf-8',(err,data)=>{
    if(err!=null)console.log(err.message)
    else{
        console.log(data);
    }
})
console.log("File reading");*/
const filename="Temp.txt";
//fs.writeFileSync(filename,"place the content in new file",'utf-8');
const emp='1,Abir,Mumbai,50000';
fs.writeFileSync(filename,emp,'utf-8');
const emp1='2,dev,delhi,90000';
fs.appendFileSync(filename,emp1,'utf-8')
