/*const readline=require('readline').createInterface({
    input:process.stdin,
    output:process.stdout
});

readline.question("What is your name?",answer=>{
    console.log(answer);
    readline.close();
})*/

const os=require('os');
console.log(os.hostname())
console.log(os.version())
console.log(os.type())
console.log(os.uptime()/3600)
console.table([
    {Name:"Abir",Address:"Mumbai"},
    {Name:"Abir",Address:"Mumbai"}
])