let fruit="apple";
function addFruit(fname){
    fruit=fname;
    console.log(fruit);
}
addFruit("mango");
console.log("The old fruit:"+fruit)

const array=[1,2,3,4,5,6];
for (const element of array){
    console.log(element)
}

function addFunc(a,b=5){
    var result=a+b;
    console.log(result)
}
addFunc(5)


const getName=(name)=>`${name}`;
console.log(getName("somename"));

const mulFunc= (a,b)=> a*b;
console.log(mulFunc(2,3))

function emp(name, address){
    this.name=name;
    this.address=address;
}
let{name,address}=new emp("Abir","Gujarat");
console.log('${name} comes from ${address}');

