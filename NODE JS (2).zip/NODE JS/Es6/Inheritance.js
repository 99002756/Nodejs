class Account{
    constructor(id,name,amount){
        this.Id=id;
        this.name=name;
        this.balance=amount;
    }
    credit(amount){
        this.balance+=amount;
    }
    debit(amount)
    {
        if(this.balance<amount)
        throw "Insufficicent funds";
        this.balance-=amount;
        }
}
class SBAccount extends Account{
    Interest(){
        let principle = this.balance;
        let ROI= 6.5;
        const year=1/4;
        const intersst=(principle*ROI*year);
        this.credit(intersst);
    }
}
try{
    const acc=new SBAccount(1,"Abir","50000")
    acc.credit(5000)
    acc.debit(5000)
    acc.Interest();
    console.log("The Balance:"+acc.balance);
}catch(er){
    console.log(er);
}
//rest and spread parameters